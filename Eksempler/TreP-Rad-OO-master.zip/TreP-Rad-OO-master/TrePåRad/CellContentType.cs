﻿namespace TrePåRad
{
    enum CellContentType
    {
        Empty = 0,
        Player1 = 1, 
        Player2 = 2
    }
}
